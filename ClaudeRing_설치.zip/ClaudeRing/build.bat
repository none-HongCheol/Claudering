@echo off
setlocal
cd /d "%~dp0"

set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FW%\csc.exe" set "FW=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
if not exist "%FW%\csc.exe" (
    echo [ERROR] Windows built-in C# compiler not found.
    echo         Check that .NET Framework 4.8 is turned on in "Turn Windows features on or off".
    pause
    exit /b 1
)
set "WPF=%FW%\WPF"

echo Closing running ClaudeRing.exe (if any) ...
taskkill /im ClaudeRing.exe /f >nul 2>nul
timeout /t 1 >nul

echo Building ClaudeRing.exe ...
"%FW%\csc.exe" /nologo /codepage:65001 /optimize+ /target:winexe /out:ClaudeRing.exe ^
  /r:"%WPF%\PresentationFramework.dll" ^
  /r:"%WPF%\PresentationCore.dll" ^
  /r:"%WPF%\WindowsBase.dll" ^
  /r:System.Xaml.dll ^
  /r:System.Windows.Forms.dll ^
  /r:System.Drawing.dll ^
  /r:System.Web.Extensions.dll ^
  ClaudeRing.cs > build_log.txt 2>&1
set "ERR=%errorlevel%"
type build_log.txt

if not "%ERR%"=="0" (
    echo.
    echo [ERROR] Build failed. Copy the messages above and show them to Claude.
    pause
    exit /b 1
)

echo.
echo Done! Starting ClaudeRing.exe ...
start "" "%~dp0ClaudeRing.exe" --demo
timeout /t 3 >nul
