@echo off
chcp 65001 >nul
title Claude 액션링 제거
setlocal
set "INSTDIR=%LOCALAPPDATA%\ClaudeRing"
set "UNINST=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ClaudeRing"

echo.
echo   Claude 액션링 제거
echo   ------------------
echo   지웁니다: 실행 중인 앱, 자동 실행 등록, 바로가기, 설치된 앱 등록, 설치 폴더
echo.
set /p ok="  정말 제거할까요? (Y/N): "
if /i not "%ok%"=="Y" ( echo   취소했어요. & pause & exit /b )

echo   [1/6] 앱 종료...
taskkill /im ClaudeRing.exe /f >nul 2>nul

echo   [2/6] 자동 실행 해제...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v ClaudeRing /f >nul 2>nul

echo   [3/6] '설치된 앱' 등록 삭제...
reg delete "%UNINST%" /f >nul 2>nul

echo   [4/6] 바로가기 삭제...
del "%USERPROFILE%\Desktop\Claude 액션링.lnk" >nul 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Claude 액션링.lnk" >nul 2>nul

echo   [5/6] 설정 폴더...
set /p cfg="  설정·색인도 지울까요? (Y/N): "
if /i "%cfg%"=="Y" rmdir /s /q "%USERPROFILE%\.claude_ring" >nul 2>nul

echo   [6/6] 설치 폴더 삭제...
start "" cmd /c "timeout /t 2 >nul & rmdir /s /q ""%INSTDIR%"""
echo.
echo   제거를 마쳤어요. 그동안 고마웠어요.
timeout /t 3 >nul
