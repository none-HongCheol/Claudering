@echo off
chcp 65001 >nul
title Claude 액션링 설치
setlocal
cd /d "%~dp0"

set "INSTDIR=%LOCALAPPDATA%\ClaudeRing"
set "EXE=%INSTDIR%\ClaudeRing.exe"
set "UNINST=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ClaudeRing"
set "VER=0.9.0"

echo.
echo   ===========================================
echo      Claude 액션링 설치   v%VER%
echo   ===========================================
echo.
echo   설치 위치: %INSTDIR%
echo   (파이썬 등 추가 설치 없이, Windows 기본 도구로 만듭니다.)
echo.

set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FW%\csc.exe" set "FW=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
if not exist "%FW%\csc.exe" (
    echo [오류] Windows 기본 C# 컴파일러를 찾지 못했어요.
    echo        "Windows 기능 켜기/끄기"에서 .NET Framework 4.8 을 켜 주세요.
    pause
    exit /b 1
)
set "WPF=%FW%\WPF"

echo   [1/5] 파일 복사...
mkdir "%INSTDIR%" 2>nul
taskkill /im ClaudeRing.exe /f >nul 2>nul
timeout /t 1 >nul
copy /y "ClaudeRing.cs" "%INSTDIR%\" >nul
copy /y "build.bat" "%INSTDIR%\" >nul
if exist "제거.bat" copy /y "제거.bat" "%INSTDIR%\" >nul

echo   [2/5] 빌드...
"%FW%\csc.exe" /nologo /codepage:65001 /optimize+ /target:winexe /out:"%EXE%" ^
  /r:"%WPF%\PresentationFramework.dll" ^
  /r:"%WPF%\PresentationCore.dll" ^
  /r:"%WPF%\WindowsBase.dll" ^
  /r:System.Xaml.dll ^
  /r:System.Windows.Forms.dll ^
  /r:System.Drawing.dll ^
  /r:System.Web.Extensions.dll ^
  "%INSTDIR%\ClaudeRing.cs" > "%INSTDIR%\build_log.txt" 2>&1
if not "%errorlevel%"=="0" (
    echo.
    echo   [오류] 빌드에 실패했어요. 아래 내용을 복사해서 보여 주세요:
    type "%INSTDIR%\build_log.txt"
    pause
    exit /b 1
)

echo   [3/5] 바로가기 만들기 (바탕화면 · 시작 메뉴)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w=New-Object -ComObject WScript.Shell;" ^
  "foreach($p in @([Environment]::GetFolderPath('Desktop'),(Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))){" ^
  "$l=$w.CreateShortcut((Join-Path $p 'Claude 액션링.lnk')); $l.TargetPath='%EXE%'; $l.WorkingDirectory='%INSTDIR%'; $l.IconLocation='%EXE%,0'; $l.Save() }" >nul 2>nul

echo   [4/5] Windows '설치된 앱'에 등록...
reg add "%UNINST%" /v DisplayName     /t REG_SZ /d "Claude 액션링" /f >nul
reg add "%UNINST%" /v DisplayVersion  /t REG_SZ /d "%VER%" /f >nul
reg add "%UNINST%" /v Publisher       /t REG_SZ /d "Claude 액션링" /f >nul
reg add "%UNINST%" /v DisplayIcon     /t REG_SZ /d "%EXE%,0" /f >nul
reg add "%UNINST%" /v InstallLocation /t REG_SZ /d "%INSTDIR%" /f >nul
reg add "%UNINST%" /v UninstallString /t REG_SZ /d "\"%INSTDIR%\제거.bat\"" /f >nul
reg add "%UNINST%" /v NoModify        /t REG_DWORD /d 1 /f >nul
reg add "%UNINST%" /v NoRepair        /t REG_DWORD /d 1 /f >nul
reg add "%UNINST%" /v EstimatedSize   /t REG_DWORD /d 1024 /f >nul

echo   [5/5] 시작 설정...
echo.
set /p auto="  Windows 켤 때 자동으로 실행할까요? (Y/N): "
if /i "%auto%"=="Y" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v ClaudeRing /t REG_SZ /d "\"%EXE%\"" /f >nul
    echo        자동 실행을 켰어요.
)

echo.
echo   설치 완료!  (Windows 설정 - 앱 - 설치된 앱 목록에서도 보여요.)
echo   - 단축키 Ctrl+Alt+Shift+F12 로 링이 열려요.
echo   - 로지텍 마우스는 Logi Options+ 에서 휠 클릭에 위 단축키를 지정하세요.
echo   - 제거: 설정 - 앱 - 설치된 앱 - Claude 액션링 - 제거, 또는 시작 메뉴의 제거.bat
echo.
start "" "%EXE%" --demo
timeout /t 3 >nul
